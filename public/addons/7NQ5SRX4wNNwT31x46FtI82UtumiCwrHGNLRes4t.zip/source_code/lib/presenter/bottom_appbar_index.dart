
class BottomAppbarIndex{
  int currentIndex=0;
   setter(index)=> currentIndex=index;
  get getter=>currentIndex;
}