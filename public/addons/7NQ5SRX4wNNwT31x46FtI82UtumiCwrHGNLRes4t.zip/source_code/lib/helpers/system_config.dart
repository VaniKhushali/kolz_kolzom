

import 'package:active_ecommerce_flutter/data_model/currency_response.dart';
import 'package:active_ecommerce_flutter/data_model/login_response.dart';

class SystemConfig{
  static CurrencyInfo? defaultCurrency;
  static CurrencyInfo? systemCurrency;
  static User? systemUser;

}