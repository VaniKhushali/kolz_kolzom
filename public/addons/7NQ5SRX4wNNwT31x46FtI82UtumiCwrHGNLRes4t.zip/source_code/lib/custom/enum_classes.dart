
// enum OffLinePaymentFor{
//   Order,WalletRecharge,PackagePay
// }
enum PaymentFor{
  Order,WalletRecharge,PackagePay,ManualPayment
}